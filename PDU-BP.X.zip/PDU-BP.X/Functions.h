/* 
 * File:   Functions.h
 * Author: Rick
 *
 * Created on May 11, 2015, 2:42 AM
 */

#ifndef FUNCTIONS_H
#define	FUNCTIONS_H

extern void Delay(long int wait);

#endif	/* FUNCTIONS_H */

