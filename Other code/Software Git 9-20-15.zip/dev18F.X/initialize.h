/*
 * File:   initialize.h
 * Author: Kilburn
 *
 * Created on February 23, 2015, 11:37 PM
 */


void initialize18F()
{
    


}