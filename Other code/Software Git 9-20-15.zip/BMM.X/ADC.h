/* 
 * File:   ADC.h
 * Author: User
 *
 * Created on June 14, 2015, 1:46 PM
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif



extern int readADC(int inputNum);


#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

