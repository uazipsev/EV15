/* 
 * File:   pwm.h
 * Author: Rick
 *
 * Created on May 21, 2015, 12:19 AM
 */

#ifndef PWM_H
#define	PWM_H

void PWM_Init(void);
void Timmer2Init(void);
void PWM1update(int output);
void PWM2update(int output);

#endif	/* PWM_H */

