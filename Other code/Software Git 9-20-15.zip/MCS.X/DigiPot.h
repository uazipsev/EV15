/* 
 * File:   DigiPot.h
 * Author: Rick
 *
 * Created on May 11, 2015, 11:48 PM
 */

#ifndef DIGIPOT_H
#define	DIGIPOT_H

void PotSetpoint(int new_point);
void PotClear(void);
extern void Delay(int wait);

#endif	/* DIGIPOT_H */

