/* 
 * File:   Bypass.h
 * Author: richc_000
 *
 * Created on April 3, 2015, 11:29 PM
 */

#ifndef BYPASS_H
#define	BYPASS_H

extern int SetBypas(int pin,int state);
extern int RunBypas();

#endif	/* BYPASS_H */

