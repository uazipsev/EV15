#include "Global.h"

volatile int receiveArray[20];
