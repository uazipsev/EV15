/* 
 * File:   PeddleFcns.h
 * Author: Rick
 *
 * Created on May 21, 2015, 2:36 AM
 */

#ifndef PEDDLEFCNS_H
#define	PEDDLEFCNS_H


#endif	/* PEDDLEFCNS_H */

