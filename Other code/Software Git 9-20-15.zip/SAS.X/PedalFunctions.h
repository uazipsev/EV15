/* 
 * File:   PedalFunctions.h
 * Author: User
 *
 * Created on May 27, 2015, 5:26 PM
 */

#ifndef PEDALFUNCTIONS_H
#define	PEDALFUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* PEDALFUNCTIONS_H */

