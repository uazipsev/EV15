#include "PeddleFcns.h"

//Get ADC stuff and analisis the data and get it ready to send, 
