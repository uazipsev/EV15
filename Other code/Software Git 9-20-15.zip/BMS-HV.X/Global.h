
extern char Temp_Aquire;
extern char Volt_Aquire;
extern long int Battery_Adc[10];
extern int Temp_Adc[4];
extern int ADC_Buffer_Point;
extern int Volt_Done;
extern int Temp_Done;
extern int CountCallBack;
#define THIS_ADDRESS 1