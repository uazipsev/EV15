/* 
 * File:   DDSBoardMain.c
 * Author: Rick
 *
 * Created on March 6, 2015, 1:51 AM
 */
#include "mcc_generated_files/mcc.h"
#include <stdio.h>
#include <stdlib.h>

SetLEDOut(char eLED)
{

}

ButtonReadIn(char ebutton)
{

}



