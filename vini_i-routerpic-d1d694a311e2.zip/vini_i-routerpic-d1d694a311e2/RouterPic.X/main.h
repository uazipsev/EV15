/* 
 * File:   main.h
 * Author: Igor
 *
 * Created on August 10, 2014, 10:42 AM
 */

#ifndef MAIN_H
#define	MAIN_H


#ifdef	__cplusplus
extern "C" {
#endif

void _general_exception_handler(void);


#ifdef	__cplusplus
}
#endif


#endif	/* MAIN_H */

