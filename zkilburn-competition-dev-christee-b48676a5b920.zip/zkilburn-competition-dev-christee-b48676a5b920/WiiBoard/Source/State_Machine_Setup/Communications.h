

FastTransfer navigationComm;

int nav_receive[10];

#define NAV_Address 1

#define DISTANCE_FROM_CENTER 1
#define BEACON_ANGLE 2
#define NUMBER_SWEEPS 3
#define BEACON_SEEN 4
#define BEACON_CENTERED 5
#define BEACON_WIDTH 6
#define TARGET_BEACON 7


#define REQUESTEDBEACON 1
