inline int setAct(int act);
inline int updateAngle();
