/* 
 * File:   Define.h
 * Author: Rick
 *
 * Created on March 25, 2015, 3:39 AM
 */

#ifndef DEFINE_H
#define	DEFINE_H

#ifdef	__cplusplus
extern "C" {
#endif

#define BATHIGH 4.21
#define BATLOW  3.00
#define TEMPHIGH 60.5


#ifdef	__cplusplus
}
#endif

#endif	/* DEFINE_H */

