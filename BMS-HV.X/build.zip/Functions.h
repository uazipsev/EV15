/* 
 * File:   Functions.h
 * Author: Rick
 *
 * Created on March 25, 2015, 10:35 PM
 */

#ifndef FUNCTIONS_H
#define	FUNCTIONS_H


void Set_4051(int Channel);


#endif	/* FUNCTIONS_H */

