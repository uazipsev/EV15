
extern char Temp_Aquire;
extern char Volt_Aquire;
extern int Battery_Adc[10];
extern int Temp_Adc[10];
extern int ADC_Buffer_Point;
extern int Volt_Done;
extern int Temp_Done;
